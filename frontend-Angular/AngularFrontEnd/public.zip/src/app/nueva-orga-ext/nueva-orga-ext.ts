import { Component } from '@angular/core';

@Component({
  selector: 'app-nueva-orga-ext',
  imports: [],
  templateUrl: './nueva-orga-ext.html',
  styleUrl: './nueva-orga-ext.css'
})
export class NuevaOrgaExt {

}
standalone: true